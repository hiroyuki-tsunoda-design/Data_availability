import pandas as pd
import subprocess
import json
import os
import time
import sys
import re
from glob import glob
from datetime import datetime

# ==============================
# 設定
# ==============================

BASE_DIR = "data_availability_project"
INPUT_DIR = os.path.join(BASE_DIR, "data_availability_all_1_1a")
OUTPUT_DIR = os.path.join(BASE_DIR, "classified_natcomm_2023_by_gemma")
FINAL_OUTPUT = os.path.join(BASE_DIR, "classified_natcomm_2023_by_gemma_all.csv")

LLAMA_MODEL = "gemma:2b"
MAX_RETRY = 3
DATA_COLUMN = "data"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ==============================
# カテゴリ定義（数値ID）
# ==============================

CATEGORY_MAP = {
    1: "Fully Public Repository Deposition",
    2: "Public Within Article / Supplement Only",
    3: "Reuse of Public Third-Party Data Only",
    4: "Mixed Public Deposit + Author Request",
    5: "Controlled-Access Repository Data",
    6: "Author Upon Request Only",
    7: "No Data Generated / Not Applicable"
}

# ==============================
# 🔥 最小プロンプト（高速化版）
# ==============================

CATEGORY_PROMPT = """
Classify the Data Availability statement into ONE category ID.

1 = Fully Public Repository Deposition
2 = Public Within Article / Supplement Only
3 = Reuse of Public Third-Party Data Only
4 = Mixed Public Deposit + Author Request
5 = Controlled-Access Repository Data
6 = Author Upon Request Only
7 = No Data Generated / Not Applicable

Return ONLY the number (1-7). No text.
"""

# ==============================
# LLM呼び出し
# ==============================

def call_llama(prompt):
    result = subprocess.run(
        ["ollama", "run", LLAMA_MODEL],
        input=prompt,
        text=True,
        capture_output=True
    )
    return result.stdout.strip()


# ==============================
# 数値抽出（JSON不要）
# ==============================

def extract_category_id(text):
    match = re.search(r"\b[1-7]\b", text)
    if match:
        return int(match.group(0))
    return None


# ==============================
# 分類関数（高速版）
# ==============================

def classify_text(text):

    prompt = f"""{CATEGORY_PROMPT}

Statement:
{text}

Answer:"""

    for attempt in range(MAX_RETRY):

        output = call_llama(prompt)

        cat_id = extract_category_id(output)

        if cat_id is not None and cat_id in CATEGORY_MAP:
            return cat_id

        time.sleep(1)

    return -1  # エラー


# ==============================
# ファイル処理
# ==============================

def process_file(input_path):

    filename = os.path.basename(input_path)
    output_path = os.path.join(OUTPUT_DIR, filename)

    print(f"\nProcessing file: {filename}")

    df = pd.read_csv(input_path)
    df.columns = df.columns.str.strip()

    if DATA_COLUMN not in df.columns:
        print(f"Column '{DATA_COLUMN}' not found in {filename}")
        print("Columns:", list(df.columns))
        return False

    category_ids = []

    for _, row in df.iterrows():
        text = str(row[DATA_COLUMN])
        cat_id = classify_text(text)
        category_ids.append(cat_id)

    # 🔥 出力は2列のみ
    out_df = pd.DataFrame({
        "PMC": df["PMC"],
        "Category_ID": category_ids
    })

    out_df.to_csv(output_path, index=False)
    print(f"Saved: {output_path}")

    return True


# ==============================
# 統合処理
# ==============================

def merge_outputs():

    print("\nMerging output files...")

    csv_files = glob(os.path.join(OUTPUT_DIR, "*.csv"))

    if not csv_files:
        print("No classified files found.")
        return

    df_list = [pd.read_csv(file) for file in csv_files]
    merged_df = pd.concat(df_list, ignore_index=True)

    merged_df.to_csv(FINAL_OUTPUT, index=False)

    print(f"Final merged file saved to: {FINAL_OUTPUT}")


# ==============================
# メイン
# ==============================

def main():

    # ==============================
    # ⏱ 開始時間
    # ==============================
    start_time = time.time()
    start_dt = datetime.now()
    print(f"Start time: {start_dt.strftime('%Y-%m-%d %H:%M:%S')}")

    if not os.path.exists(INPUT_DIR):
        print("Input directory not found:", INPUT_DIR)
        sys.exit(1)

    input_files = glob(os.path.join(INPUT_DIR, "*.csv"))

    if not input_files:
        print("No CSV files found.")
        sys.exit(1)

    processed_files = set(
        os.path.basename(f)
        for f in glob(os.path.join(OUTPUT_DIR, "*.csv"))
    )

    print(f"Total input files: {len(input_files)}")
    print(f"Already processed files: {len(processed_files)}")
    print("Starting classification...\n")

    completed = len(processed_files)
    total_files = len(input_files)

    for file_path in input_files:

        filename = os.path.basename(file_path)

        if filename in processed_files:
            print(f"Skipping (already processed): {filename}")
            continue

        success = process_file(file_path)

        if success:
            completed += 1

        print(f"[{completed}/{total_files}] Files processed")

    print("\nAll files processed.")

    merge_outputs()

    # ==============================
    # ⏱ 終了時間と処理時間
    # ==============================
    end_time = time.time()
    end_dt = datetime.now()
    elapsed = end_time - start_time

    print("\n==============================")
    print(f"End time:   {end_dt.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Elapsed time: {elapsed:.2f} seconds")
    print("==============================")


if __name__ == "__main__":
    main()